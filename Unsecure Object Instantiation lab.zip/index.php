<?php
// Load tasks classes
@include_once(__dir__ . "/classes/cleaning.php");
@include_once(__dir__ . "/classes/cooking.php");
@include_once(__dir__ . "/classes/charging.php");
// Check if "task" and "args" parameters are not empty
if( !empty($_GET['task']) && !empty($_GET['args']) ) {
    try {
        // Declare Reflection class from given class name
        $task = new ReflectionClass( $_GET['task'] );
        // Creates a new class instance from given arguments
        $task->newInstanceArgs( $_GET['args'] );
    } catch (Exception $e) {
        // If there is error, view error page
        @include(__dir__ . "/views/error.html");
    }
} else {
    // If missing required parameters, view docs page
    @include(__dir__ . "/views/docs.html");
}