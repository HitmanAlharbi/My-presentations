<?php

class cleaning{

    private $room = null;
    private $bot = null;

    function __construct($bot, $room){
        // Set which room to clean
        $this->room = $room ?? null;
        // Set which bot to do the clean
        $this->bot = $bot ?? null;
        // Start cleaning process
        $this->doClean();
    }

    function doClean(){
        // For example let's print a text
        echo($this->bot . " is cleaning " . $this->room);
    }

}