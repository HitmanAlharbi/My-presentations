<?php

class cooking{

    private $food = null;
    private $bot = null;

    function __construct($food, $bot){
        // Set which food to cook
        $this->food = $food ?? null;
        // Set which bot to do the cook
        $this->bot = $bot ?? null;
        // Start cooking process
        $this->doCook();
    }

    function doCook(){
        // For example let's print a text
        echo($this->bot . " is cooking " . $this->food);
    }

}