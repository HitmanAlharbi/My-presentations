<?php

class charging{

    private $bot = null;

    function __construct($bot){
        // Set which bot to start charging
        $this->bot = $bot ?? null;
        // Start charging process
        $this->doCharging();
    }

    function doCharging(){
        // For example let's print a text
        echo($this->bot . " is charging now");
    }

}